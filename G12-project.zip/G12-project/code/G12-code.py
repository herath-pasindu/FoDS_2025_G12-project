

#Data inspection and prepocessing

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_validate
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import make_scorer, classification_report, confusion_matrix, accuracy_score, recall_score, precision_score, f1_score, roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import randint
from sklearn.linear_model import LogisticRegression


# to make all columns of the df visible but not all rows (too much)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 20)


# Load the data set with appropriate dtypes
###### MATCH THE PATH TO THE DATASET IN YOUR COMPUTER ######

data = pd.read_csv("../data/2025_cardio_train.csv",  
                   dtype={
                       "id": "string",
                       "age": np.int64,
                       "gender": np.int64,  # temporary, will remap
                       "height": np.int64,
                       "weight": np.float64,
                       "ap_hi": np.int64,
                       "ap_lo": np.int64,
                   })

# Recode and convert columns
data["gender"] = data["gender"].map({1: 1, 2: 0}).astype("category")

ordered_3lvl = pd.CategoricalDtype(categories=[1, 2, 3], ordered=True)
binary_cat = pd.CategoricalDtype(categories=[0, 1], ordered=False)

data["cholesterol"] = data["cholesterol"].astype(ordered_3lvl)
data["gluc"] = data["gluc"].astype(ordered_3lvl)
data["smoke"] = data["smoke"].astype(binary_cat)
data["alco"] = data["alco"].astype(binary_cat)
data["active"] = data["active"].astype(binary_cat)
data["cardio"] = data["cardio"].astype(int)

# Check whether the dtypes are correct
data.dtypes


# Change age from days to years - easier to interpret
# Floor division to get the number of completed full years
data["age"] = data["age"] // 365


# Check the data
data.head(20)


##################################
######### Data Overview ##########
##################################

# Define a function to get an overview of the dataset
def df_overview(df, target_classes):
    print('-'*51)
    print('-'*19, 'CVD DATASET', '-'*19)
    print('-'*51)
    print('No. of patients in the dataset:', ' '*13, '{}'.format(df.shape[0]))
    print('No. of attributes in the dataset:', ' '*14, '{}'.format(df.shape[1]-2)) # id and cardio are excluded
    print('No. of duplicated rows in the dataset:',' '*10, '{}'.format(df.duplicated().sum(axis=0)))
    print('No. of missing values in the dataset:',' '*11, '{}'.format(df.isna().sum(axis=0).sum()))
    # Checking whether the class variable is balanced
    for i in range(2):
        print('No. of {}:'.format(target_classes[i]), ' '*23, df["cardio"].value_counts()[i])
        print('Proportion of {}:'.format(target_classes[i]), ' '*15, '{:.4f}'.format(df["cardio"].value_counts()[i] / df.shape[0]))
    if (df["cardio"].value_counts()[1] / df.shape[0] > 0.5 or df["cardio"].value_counts()[0] / df.shape[0] > 0.5):
        if abs((df["cardio"].value_counts()[1] - df["cardio"].value_counts()[0]) / df.shape[0]) < 0.1:
            print('The class distribution is approximately balanced.')
        else:
            print('The class distribution is not balanced.')
    else:
        print('The class distribution is balanced.')
    print('-'*51)
    print('')
    print('Descriptive Statistics:') # To check whether numerical attributes contain any unrealistic values
    print(df.describe())

# Create a list for target classes
neg_pos = ["CVD negatives", "CVD positives"]

# Output the data overview
df_overview(data, neg_pos)
print()


# Observe unrealistic numerical values - negative systolic & diastolic pressures, 10 kg male person is 51 years old and 165 cm tall, etc.
# Solution - Setting realistic thresholds and logics to numerical attributes

# Create the BMI variable to help in detecting unrealistic weight-height combinations
data["bmi"] = data["weight"] / (data["height"] / 100) ** 2

# Define realistic ranges and filter the data (age has a valid range from 29 to 64 years -> no range defined)
# Ranges are obtained from reliable sources
valid_rows = (
    (data["height"] >= 120) & (data["height"] <= 220) & 
    (data["bmi"] >= 15) & (data["bmi"] <= 100) &
    (data["weight"] >= 30) &                            # derived from the ranges for height and bmi
    (data["ap_hi"] >= 80) & (data["ap_hi"] <= 200) &    # systolic blood pressure range
    (data["ap_lo"] >= 40) & (data["ap_lo"] <= 130) &    # diastolic blood pressure range
    (data["ap_hi"] > data["ap_lo"])                     # logic - systolic is always higher than diastolic
)

# Apply the filters and create a cleaned copy of the dataset
data_clean = data[valid_rows].copy()

# Output the cleaned data overview
print(' '*22 + 'CLEANED')
df_overview(data_clean, neg_pos)
print()


categorical_vars = ["gender", "smoke", "alco", "active", "cholesterol", "gluc"]

# Nominal categorical variables
nominal_vars = ["gender", "smoke", "alco", "active"]

# Numerical variables
numerical_vars = ["age", "height", "weight", "ap_hi", "ap_lo"] # bmi is not used as weight and height are used

##################################
######## One-Hot Encoding ########
##################################

# Make a copy of the dataset, just in case
data_clean_copy = data_clean.copy()

# One-hot encoding for nominal categorical variables before train test split
data_encoded = pd.get_dummies(data_clean_copy, columns = nominal_vars, drop_first = True, dtype = int)


##################################
########### Splitting ############
##################################

# Retaining ids if we want to match predictions to patients later
ids = data_encoded["id"]

# Separate the class from the attributes
X = data_encoded.drop(["id", "bmi", "cardio"], axis = 1)
y = data_encoded["cardio"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, stratify = y, random_state = 2025) # Keep the same random state for reproducability


##################################
############ Scaling #############
##################################

# Create copies of the data to avoid inplace operations
X_train_scaled, X_test_scaled = X_train.copy(), X_test.copy()

# Scale
sc = StandardScaler()
X_train_scaled[numerical_vars] = sc.fit_transform(X_train_scaled[numerical_vars])
X_test_scaled[numerical_vars] = sc.transform(X_test_scaled[numerical_vars])


##################################
##### Descriptive Statistics #####
##################################


# Dictionary to map dataset column names to appropriate names for plots
var_names = {
    "age": "Age ",
    "height": "Height ",
    "weight": "Weight ",
    "ap_hi": "Systolic BP ",
    "ap_lo": "Diastolic BP ",
    "gender": "Gender",
    "smoke": "Smoking status",
    "alco": "Alcohol intake",
    "active": "Physical activity",
    "cardio": "Cardiovascular disease",
    "cholesterol": "Cholesterol Level",
    "gluc": "Glucose Level"
}

# Dictionary to map numerical variable names to appropriate units for the axis labels
var_unit = {
    "age": " Age [years]",
    "height": " Height [cm]",
    "weight": " Weight [kg]",
    "ap_hi": " Systolic BP [mmHg]",
    "ap_lo": " Diastolic BP [mmHg]"
    }

# Dictionary to map categorical variable names with appropriate names for the plots
label_maps = {
    "gender": {0: "Male", 1: "Female"},
    "active": {0: "Inactive", 1: "Active"},
    "alco": {0: "No alcohol", 1: "Alcohol"},
    "smoke": {0: "Non-smoker", 1: "Smoker"},
    "cardio": {0: "No CVD", 1: "CVD"},
    "cholesterol" : {1: "normal", 2: "above normal", 3: "well above normal"},
    "gluc": {1: "normal", 2: "above normal", 3: "well above normal"}
}

# Replace coded categorical values with their corresponding labels using label_maps:
for col, mapping in label_maps.items():
    if col in data.columns:
        data[col] = data[col].map(mapping)

for col, mapping in label_maps.items():
    if col in data_clean.columns:
        data_clean[col] = data_clean[col].map(mapping)

# PLOTS FOR THE RAW DATA:

# Categorical variables:
fig, axs = plt.subplots(2, 3, figsize=(20, 15))
axs = axs.flatten()

for ax, var in zip(axs, categorical_vars):
    sns.countplot(data = data, x = var, hue="cardio", ax=ax)
    ax.set_title(f"Plot for {var_names[var]}")
    ax.set_xlabel(f"Variable: {var_names[var]}")
    ax.set_ylabel("numbers of cases")

plt.tight_layout()
plt.subplots_adjust(wspace=0.2, hspace=0.2)
plt.savefig(
    f"../output/plot_CVD_raw_categorical.pdf",
    backend ="pdf"
)
plt.close(fig)


# Numerical variables:
fig, axs = plt.subplots(2, 3, figsize=(30, 20))
axs = axs.flatten()

# because we want only 5 graphs, the last axis (6th plot) should be deleted
fig.delaxes(axs[5])

for ax, var in zip(axs, numerical_vars):
    sns.violinplot(x = "cardio" ,y = var,data = data, ax=ax)
    ax.set_title(f"Plot for {var_names[var]}", fontsize = 20)
    ax.set_xlabel("CVD diagnosis", fontsize = 15)
    ax.set_ylabel(f"Variable: {var_unit[var]}", fontsize = 15)
    ax.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.subplots_adjust(wspace=0.2, hspace=0.15)
plt.savefig(
    f"../output/plot_CVD_raw_numerical.pdf",
    backend="pdf"
)
plt.close(fig)

# PLOTS FOR THE CLEAN DATA:

# Categorical variables:
fig, axs = plt.subplots(2, 3, figsize=(20, 15))
axs = axs.flatten()

for ax, var in zip(axs, categorical_vars):
    sns.countplot(data = data_clean, x = var, hue="cardio", ax=ax)
    ax.set_title(f"Cleaned plot for {var_names[var]}")
    ax.set_xlabel(f"Variable: {var_names[var]}")
    ax.set_ylabel("numbers of cases")

plt.tight_layout()
plt.subplots_adjust(wspace=0.2, hspace=0.2)
plt.savefig(
    f"../output/plot_CVD_clean_categorical.pdf",
    backend="pdf"
)
plt.close(fig)

# Numerical variables:
fig, axs = plt.subplots(2, 3, figsize=(30, 20))
axs = axs.flatten()

# because we want only 5 graphs, the last axis (6th plot) should be deleted
fig.delaxes(axs[5])

for ax, var in zip(axs, numerical_vars):
    sns.violinplot(x = "cardio" ,y = var,data = data_clean, ax=ax)
    ax.set_title(f"Cleaned plot for {var_names[var]}", fontsize = 20)
    ax.set_xlabel("CVD diagnosis", fontsize = 15)
    ax.set_ylabel(f"Variable: {var_unit[var]}", fontsize = 15)
    ax.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.subplots_adjust(wspace=0.2, hspace=0.15)
plt.savefig(
    f"../output/plot_CVD_clean_numerical.pdf",
    backend="pdf"
)
plt.close(fig)


##################################
############ Models ##############
##################################


#######################################
####### Logistic Regrssion (LR) #######
#######################################
print("\n")
print("Logistic Regression: ")

# Define a scoring metric - Chose accuracy because the dataset is balanced
scorer = make_scorer(accuracy_score)


# Function to perform hyperparameter tuning and cross-validation
def cross_val_with_hyperparameter_tuning(X_train_scaled, y_train, scorer):
    # Set the no. of folds
    skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=2025)

    # Hyperparameter tuning to get the best value for regularization strength
    param_grid = {'C': [0.0001, 0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000]}
    logreg = LogisticRegression(max_iter=1000, penalty='l2', random_state=2025)
    grid_search = GridSearchCV(logreg, param_grid, cv=skf, scoring=scorer)
    grid_search.fit(X_train_scaled, y_train)
    best_C = grid_search.best_params_['C']
    print("Best parameter for regularization strength (C): ", best_C)

    # Empty arrays to store evaluation metrics of each validation step
    accuracies = []
    recalls = []
    precisions = []
    f1s = []
    roc_aucs = []

    # Splitting and training with the best C - to get the training performance
    for train_index, test_index in skf.split(X_train_scaled, y_train):
        X_train_fold, X_test_fold = X_train_scaled.iloc[train_index, :], X_train_scaled.iloc[test_index, :]
        y_train_fold, y_test_fold = y_train.iloc[train_index], y_train.iloc[test_index]

        # Initialize the model
        fold_model = LogisticRegression(max_iter=1000, penalty='l2', C=best_C, random_state=2025)
        # Fit to the model
        fold_model.fit(X_train_fold, y_train_fold)

        # Test on the test fold in CV
        y_pred = fold_model.predict(X_test_fold)
        y_pred_prob = fold_model.predict_proba(X_test_fold)[:, 1]  # for the ROC AUC metric

        # Fill up the arrays for metrics
        accuracies.append(accuracy_score(y_test_fold, y_pred))
        recalls.append(recall_score(y_test_fold, y_pred))
        precisions.append(precision_score(y_test_fold, y_pred))
        f1s.append(f1_score(y_test_fold, y_pred))
        roc_aucs.append(roc_auc_score(y_test_fold, y_pred_prob))

    # Output the performance in training (= 10 fold CV)
    print("\nTraining set performance:")
    print("Accuracy: {:.4f} ± {:.4f}".format(np.mean(accuracies), np.std(accuracies)))
    print("Recall: {:.4f} ± {:.4f}".format(np.mean(recalls), np.std(recalls)))
    print("Precision: {:.4f} ± {:.4f}".format(np.mean(precisions), np.std(precisions)))
    print("F1 Score: {:.4f} ± {:.4f}".format(np.mean(f1s), np.std(f1s)))
    print("ROC AUC: {:.4f} ± {:.4f}".format(np.mean(roc_aucs), np.std(roc_aucs)))

    return grid_search.best_estimator_


# Train the LR model
LR_model = cross_val_with_hyperparameter_tuning(X_train_scaled, y_train, scorer)

# Evaluate on the TEST set
y_pred = LR_model.predict(X_test_scaled)
y_pred_prob = LR_model.predict_proba(X_test_scaled)[:, 1]

# Output the performance on the TEST set
print("\nTest set performance:")
print("Accuracy: {:.4f}".format(accuracy_score(y_test, y_pred)))
print("Recall: {:.4f}".format(recall_score(y_test, y_pred)))
print("Precision: {:.4f}".format(precision_score(y_test, y_pred)))
print("F1 Score: {:.4f}".format(f1_score(y_test, y_pred)))
print("ROC AUC: {:.4f}".format(roc_auc_score(y_test, y_pred_prob)))


# A function to output coefficients of features in the LR model as a table
def output_coefficients_table(features, coefficients):
    # Create a DataFrame to store the coefficients
    coefficients_df = pd.DataFrame({'Feature': features, 'Coefficient': coefficients})
    # Convert coefficients to float for sorting
    coefficients_df['Coefficient'] = coefficients_df['Coefficient'].astype(np.float64)
    # Sort by absolute value
    coefficients_df = coefficients_df.sort_values(by='Coefficient', key=lambda x: x.abs(), ascending=False)
    # Format coefficient to 4 decimal places
    coefficients_df['Coefficient'] = coefficients_df['Coefficient'].apply(lambda x: "{:.4f}".format(x))
    # Print the DataFrame
    print(coefficients_df)


# Extract the features
features = X_train_scaled.columns

# Extract the coefficients of features in the LR model
coefficients = LR_model.coef_[0]

print("\nCoefficients for features:")

output_coefficients_table(features, coefficients)
print()


# Sort before visualizing
sorted_df = pd.DataFrame({'Feature': features, 'Coefficient': coefficients}).sort_values(by='Coefficient',
                                                                                         key=lambda x: x.abs(),
                                                                                         ascending=True)

# Visualize coefficients
plt.figure(figsize=(10, 6))
plt.barh(sorted_df['Feature'], sorted_df['Coefficient'])
plt.xlabel('Coefficient value')
plt.ylabel('Feature')
plt.title('Logistic Regression Coefficients')
plt.tight_layout()
plt.savefig('../output/coeff_LR_model.pdf')


#######################################
######### Decision Tree (DT) ##########
#######################################

print("\n")
print("Decision Tree: ")

# Define the hyperparameter ranges for randomized search
param_dt = {
    'max_depth': [5, 10, 20, 30],
    'min_samples_split': [2, 5, 10, 20],
    'min_samples_leaf': [1, 2, 4, 10],
    'max_features': ['sqrt', 'log2', None],
    'class_weight': ['balanced']
}

"""
# Set up randomized search with 150 iterations and 20-fold CV
# We took this part out, because of too long computational time and used the alternative manual code to run the project
dt = RandomizedSearchCV(
    estimator=DecisionTreeClassifier(random_state=2025),
    param_distributions=param_dt,
    n_iter=150,
    scoring = 'f1',
    cv=20,
    n_jobs=-1,
    random_state = 2025
)

# To know which parameter were the best in the randomized search:
# print("Best DT Parameters:", dt.best_params_)
# print("Best DT Score (F1):", dt.best_score_)
"""

# Alternative: manually insert parameters from Randomized Search for faster script execution (values were obtained after running RandomizedSearchCV once)
dt = DecisionTreeClassifier(min_samples_split=5, min_samples_leaf=10, max_depth=10, class_weight='balanced', random_state=2025)

# Fit the model
dt.fit(X_train_scaled, y_train)

# Predict on the test set
y_pred_dt = dt.predict(X_test_scaled)
y_proba_dt = dt.predict_proba(X_test_scaled)[:, 1]  # for ROC AUC

# Confusion matrix
print("confusion matrix: ", confusion_matrix(y_test, y_pred_dt),"\n")

# Evaluate using 10-fold CV on training set
scoring = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
cv_results = cross_validate(dt, X_train_scaled, y_train, cv=10, scoring=scoring, return_train_score=False)

print("Performance metrics Decision Tree: ")
for metric in scoring:
    scores_dt = cv_results[f'test_{metric}']
    print(f'{metric.capitalize()}: {scores_dt.mean():.4f} ± {scores_dt.std():.4f}')

# Test set performance
test_accuracy_dt = accuracy_score(y_test, y_pred_dt)
test_recall_dt = recall_score(y_test, y_pred_dt)
test_precision_dt = precision_score(y_test, y_pred_dt)
test_f1_dt = f1_score(y_test, y_pred_dt)
test_roc_auc_dt = roc_auc_score(y_test, y_proba_dt)

print("\nTest Set Performance Decision Tree: ")
print(f"Accuracy: {test_accuracy_dt:.4f}")
print(f"Recall: {test_recall_dt:.4f}")
print(f"Precision: {test_precision_dt:.4f}")
print(f"F1 Score: {test_f1_dt:.4f}")
print(f"ROC AUC: {test_roc_auc_dt:.4f}")

# Feature importance from the best model
# No need to extract the best estimator again as it was done with the manually alternative and not the randomized search
# best_dt = dt.best_estimator_
importances_dt = dt.feature_importances_
feature_importance_dt = pd.Series(importances_dt, index= X_train_scaled.columns).sort_values(ascending=False)

# Plot feature importances
plt.figure(figsize = (10,6))
sns.barplot(x= feature_importance_dt.values, y=feature_importance_dt.index)
plt.xlabel("Feature importance")
plt.ylabel("Feature")
plt.title("Decision Tree - Feature importances")

plt.savefig("../output/feature_importances_dt.pdf",
                format="pdf"
            )

#######################################
######### Random Forest (RF) ##########
#######################################
print("\n")
print("Random Forest: ")

# Define the hyperparameter ranges for Randomized Search
param_rf = {
    'n_estimators': randint(50,300),
    'max_depth': [5, 10, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2'],
    'class_weight': ['balanced']
}

"""""
# Set up randomized hyperparameter search with 10-fold cross-validation and 50 iterations
# We took this part out, because of too long computational time, and used the alternative manual code to run the project
rf = RandomizedSearchCV(
    estimator=RandomForestClassifier(random_state=2025),
    param_distributions=param_rf,
    n_iter=50,
    scoring = 'f1',
    cv=10,
    n_jobs=-1,
    random_state = 2025
)

# To know which parameter were the best in the randomized search:
print("Best RF Parameters:", rf.best_params_)
print("Best RF Score (F1):", rf.best_score_)
"""

# Alternative: manually insert parameters from the RandomizedSearchCV for faster script execution (values were obtained after running RandomizedSearchCV once)
rf = RandomForestClassifier(class_weight='balanced', max_features='sqrt', min_samples_leaf=4, min_samples_split=10, n_estimators=126,random_state=2025)

# Fit the RF model to the training data
rf.fit(X_train_scaled, y_train)

# Evaluate on the test set
y_pred_rf = rf.predict(X_test_scaled)
y_proba_rf = rf.predict_proba(X_test_scaled)[:, 1]  # for ROC AUC

# Output the confusion matrix
print("confusion matrix: ", confusion_matrix(y_test, y_pred_rf), "\n")

# Output the confusion matrix
scoring = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']

# Perform 10-fold CV to evaluate training performance
cv_results = cross_validate(rf, X_train_scaled, y_train, cv=10, scoring=scoring, return_train_score=False)

# Output mean ± std of metrics across folds
print("Performance metrics Random Forest: ")
for metric in scoring:
    scores_rf = cv_results[f'test_{metric}']
    print(f'{metric.capitalize()}: {scores_rf.mean():.4f} ± {scores_rf.std():.4f}')

# Evaluate and output test set performance
test_accuracy_rf = accuracy_score(y_test, y_pred_rf)
test_recall_rf = recall_score(y_test, y_pred_rf)
test_precision_rf = precision_score(y_test, y_pred_rf)
test_f1_rf = f1_score(y_test, y_pred_rf)
test_roc_auc_rf = roc_auc_score(y_test, y_proba_rf)

print("\nTest Set Performance Random Forest:")
print(f"Accuracy: {test_accuracy_rf:.4f}")
print(f"Recall: {test_recall_rf:.4f}")
print(f"Precision: {test_precision_rf:.4f}")
print(f"F1 Score: {test_f1_rf:.4f}")
print(f"ROC AUC: {test_roc_auc_rf:.4f}")

# Extract and visualize feature importances from the trained RF model
# No need to extract the best estimator again as it was done with the manually alternative and not the randomized search
# best_rf = rf.best_estimator_
importances_rf = rf.feature_importances_
feature_names_rf = X.columns

# Create a DataFrame with feature importances and sort by importance
feat_imp_rf = pd.DataFrame({
    'Feature': feature_names_rf,
    'Importance': importances_rf
}).sort_values(by='Importance', ascending=False)

# Plot feature importances
plt.figure(figsize = (10,6))
sns.barplot(data=feat_imp_rf, x='Importance', y='Feature')
plt.xlabel("Feature importance")
plt.ylabel("Feature")
plt.title("Random Forest - Feature importances")

plt.savefig("../output/feature_importances_rf.pdf",
                format="pdf"
            )




